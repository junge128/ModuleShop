#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import json
import requests
import subprocess
import re
from v2ray_util.util_core.loader import Loader
from v2ray_util.main import menu
from v2ray_util.config_modify import base, multiple, ss, stream, tls, cdn
from v2ray_util.util_core.v2ray import V2ray
from tornado.web import Application, RequestHandler
from tornado.ioloop import IOLoop
from tornado.httpserver import HTTPServer
  
class IndexHandler(RequestHandler):

    def get(self):
        self.write("IndexTest")
     
class readconfig(RequestHandler):

    def get(self):
        self.set_header('Access-Control-Allow-Origin', '*') 
        self.set_header('Access-Control-Allow-Headers', '*')
        self.set_header('Access-Control-Allow-Methods', '*')
        self.set_header('Content-type', 'application/json')
        
        self.write(Read().readlocal())
        
class add(RequestHandler):

    def get(self):
        self.set_header('Access-Control-Allow-Origin', '*') 
        self.set_header('Access-Control-Allow-Headers', '*')
        self.set_header('Access-Control-Allow-Methods', '*')
        self.set_header('Content-type', 'application/json')
        
#        email = self.get_query_argument("email")
#        multiple.new_user2(email)
#        V2ray.restart()
#        旧版新用户添加 uuid每个服务端不一样 仅需email参数
        
        email = self.get_query_argument("email")
        uuid = self.get_query_argument("uuid")
        config_ = open('/etc/v2ray/config.json')
        config_ = config_.read()
        config_ = json.loads(config_)
        config_clients = config_['inbounds'][0]['settings']['clients']
        temp = {'alterId': 32,'id': uuid,'email': email}
        config_clients.append(temp)
        config_['inbounds'][0]['settings']['clients'] = config_clients
        with open("/etc/v2ray/config.json", "w") as f:
            json.dump(config_, f)
        V2ray.restart()
        #新版多了一个参数uuid uuid由主服务器统一生成 通过直接写入config文件 重启 添加
        
class delete(RequestHandler):

    def get(self):
        self.set_header('Access-Control-Allow-Origin', '*') 
        self.set_header('Access-Control-Allow-Headers', '*')
        self.set_header('Access-Control-Allow-Methods', '*')
        self.set_header('Content-type', 'application/json')

        email = self.get_query_argument("email")
        index = Read().readindex(email)[0]
        multiple.del_user2(index)
        
class checkuid(RequestHandler):

    def get(self):
        self.set_header('Access-Control-Allow-Origin', '*') 
        self.set_header('Access-Control-Allow-Headers', '*')
        self.set_header('Access-Control-Allow-Methods', '*')
        self.set_header('Content-type', 'application/json')

        email = self.get_query_argument("email")
        uuid = Read().readindex(email)[1]
        self.write(uuid)
   
class Read():
    
    def Get(self):
        response1 = requests.get('http://207.148.118.141:8000/readconfig/').text
        return response1

    def readindex(self,o_email): #通过 邮箱号读取 index
        text = self.readlocal()
        ssrlist = json.loads(text)
        newlist = ssrlist['inbounds'][0]['settings']['clients']
        
        for i in range(0,len(newlist)):
            email = str(newlist[i]['email'])
            uuid = str(newlist[i]['id'])
            result = [str(i+1),uuid]
            if email == o_email:
                return result

    def readlocal(self):  #读取本地 config.json
        FILE_PATH = "/etc/v2ray/config.json"
        f = open(FILE_PATH)
        jsontext = f.read()
        return jsontext
     
class getstats(RequestHandler):
    def get(self):
        self.set_header('Access-Control-Allow-Origin', '*') 
        self.set_header('Access-Control-Allow-Headers', '*')
        self.set_header('Access-Control-Allow-Methods', '*')
        self.set_header('Content-type', 'application/json')
        
        self.write(self.read())
    
    def read(self):
        loader = Loader()
        profile = loader.profile
        port = str(profile.stats.door_port) #得到server port
        cmd = "/usr/bin/v2ray/v2ctl api --server=127.0.0.1:" + port + " StatsService.QueryStats 'pattern: \"\" reset: true'"
        result = bytes.decode(subprocess.run(cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL).stdout.strip())
        return result

if __name__ == "__main__":
    app = Application(
        [
            (r"/", IndexHandler),
            (r"/add/", add),
            (r"/delete/", delete),
            (r"/checkuid/", checkuid),
            (r"/readconfig/", readconfig),
            (r"/getstats/", getstats),
        ]
    )
    
    http_server = HTTPServer(app)
    http_server.listen(8000)
    IOLoop.current().start()