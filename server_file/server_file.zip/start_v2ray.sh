#!/usr/bin/env bash
#description:开机自启脚本
nohup python3 /usr/local/v2ray.py &