# -*- coding: utf-8 -*-
"""
Created on Mon Mar 16 03:13:43 2020

@author: GeJun
"""
from v2ray_util.util_core.v2ray import V2ray

V2ray.restart()